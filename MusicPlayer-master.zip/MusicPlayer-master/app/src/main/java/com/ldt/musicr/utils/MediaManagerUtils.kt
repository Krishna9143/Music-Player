package com.ldt.musicr.utils

import com.ldt.musicr.model.Song
import com.ldt.musicr.model.mp.MPPlaylist

/**
 * Utils for [com.ldt.musicr.common.MediaManager]
 */
object MediaManagerUtils {
/*    fun getPlaylistAllSongs(): Pair<MPPlaylist, List<Song>> {

    }*/
}