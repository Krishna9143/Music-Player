package com.ldt.musicr.helper;

public interface M3UConstants {
    String EXTENSION = "m3u";
    String HEADER = "#EXTM3U";
    String ENTRY = "#EXTINF:";
    String DURATION_SEPARATOR = ",";
}