package com.ldt.musicr.ui.maintab.library.viewholder

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ldt.musicr.R
import com.ldt.musicr.notification.ActionResponder

class SortingTileViewHolder(parent: ViewGroup, actionResponder: ActionResponder?): RecyclerView.ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_sort_song_child, parent, false)) {

}